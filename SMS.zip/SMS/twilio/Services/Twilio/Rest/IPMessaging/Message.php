<?php

class Services_Twilio_Rest_IPMessaging_Message extends Services_Twilio_IPMessagingInstanceResource {

}
